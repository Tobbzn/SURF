function [ p_new ] = pupdate(p,U)
    
    uvec = [U(1:3:(end-2)) U(2:3:(end-1)) U(3:3:end)];
   
    p_new=p+uvec;
   
end

