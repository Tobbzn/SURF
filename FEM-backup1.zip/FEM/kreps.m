

k=10000;
for i=1:k
    x=i/k;
    waitbar(x);
end

