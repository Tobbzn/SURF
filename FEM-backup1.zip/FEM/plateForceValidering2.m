function [ pf  ] = plateForceValidering2( f,loadrate,maxf,minf,t,period )


pf=-period*loadrate;

end



